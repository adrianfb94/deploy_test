#ifndef PARSE_LITERALS_H
#define PARSE_LITERALS_H

#include <vector>
#include <string>

int literalsFindDatatype(const int n, const std::vector<std::string> &literals);
int literalGetDatatype(const std::string &literal);
int literal2int(const std::string &literal);
double literal2double(const std::string &literal);

#endif
