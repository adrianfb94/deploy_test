#ifndef PROGRESS_H
#define PROGRESS_H

namespace progress
{

extern bool stdout_is_tty;
extern bool silentMode;

void init();
void init(const char *p_context);
void update(double offset, double refval, double curval);
void setContextFunction(const char *(*func)(void));

}  // namespace progress

#endif
