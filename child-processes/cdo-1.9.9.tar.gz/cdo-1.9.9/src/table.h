#ifndef TABLE_H
#define TABLE_H

int defineTable(const char *tablearg);

#endif
