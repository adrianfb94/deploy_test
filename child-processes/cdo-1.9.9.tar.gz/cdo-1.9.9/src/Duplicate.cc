/*
  This file is part of CDO. CDO is a collection of Operators to
  manipulate and analyse Climate model Data.

  Copyright (C) 2003-2020 Uwe Schulzweida, <uwe.schulzweida AT mpimet.mpg.de>
  See COPYING file for copying and redistribution conditions.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; version 2 of the License.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
*/

#include <cdi.h>

#include "cdo_options.h"
#include "process_int.h"
#include "cdo_vlist.h"
#include "param_conversion.h"


void *
Duplicate(void *process)
{
  int nrecs;
  int varID, levelID;

  cdoInitialize(process);

  if (operatorArgc() > 1) cdoAbort("Too many arguments!");

  const auto ndup = (operatorArgc() == 1) ? parameter2int(cdoOperatorArgv(0)) : 2;
  if (Options::cdoVerbose) cdoPrint("ndup = %d", ndup);

  const auto streamID1 = cdoOpenRead(0);

  const auto vlistID1 = cdoStreamInqVlist(streamID1);
  const auto vlistID2 = vlistDuplicate(vlistID1);

  const auto taxisID1 = vlistInqTaxis(vlistID1);
  const auto taxisID2 = taxisDuplicate(taxisID1);
  vlistDefTaxis(vlistID2, taxisID2);

  const auto nvars = vlistNvars(vlistID1);
  auto ntsteps = vlistNtsteps(vlistID1);

  if (ntsteps == 1)
    {
      for (varID = 0; varID < nvars; ++varID)
        if (vlistInqVarTimetype(vlistID1, varID) != TIME_CONSTANT) break;

      if (varID == nvars) ntsteps = 0;
    }

  if (ntsteps == 0)
    {
      for (varID = 0; varID < nvars; ++varID) vlistDefVarTimetype(vlistID2, varID, TIME_VARYING);
    }

  const auto streamID2 = cdoOpenWrite(1);
  cdoDefVlist(streamID2, vlistID2);

  VarList varList;
  varListInit(varList, vlistID1);

  FieldVector3D vars;
  std::vector<int64_t> vdate;
  std::vector<int> vtime;

  int tsID = 0;
  while ((nrecs = cdoStreamInqTimestep(streamID1, tsID)))
    {
      constexpr size_t NALLOC_INC = 1024;
      if ((size_t) tsID >= vdate.size()) vdate.resize(vdate.size() + NALLOC_INC);
      if ((size_t) tsID >= vtime.size()) vtime.resize(vtime.size() + NALLOC_INC);
      if ((size_t) tsID >= vars.size()) vars.resize(vars.size() + NALLOC_INC);

      vdate[tsID] = taxisInqVdate(taxisID1);
      vtime[tsID] = taxisInqVtime(taxisID1);

      fieldsFromVlist(vlistID1, vars[tsID]);

      for (int recID = 0; recID < nrecs; recID++)
        {
          cdoInqRecord(streamID1, &varID, &levelID);
          auto &field = vars[tsID][varID][levelID];
          field.init(varList[varID]);
          cdoReadRecord(streamID1, field);
        }

      tsID++;
    }

  int nts = tsID;

  for (int idup = 0; idup < ndup; idup++)
    {
      for (tsID = 0; tsID < nts; tsID++)
        {
          taxisDefVdate(taxisID2, vdate[tsID]);
          taxisDefVtime(taxisID2, vtime[tsID]);
          cdoDefTimestep(streamID2, idup * nts + tsID);

          for (varID = 0; varID < nvars; varID++)
            {
              for (levelID = 0; levelID < varList[varID].nlevels; levelID++)
                {
                  auto &field = vars[tsID][varID][levelID];
                  if (field.hasData())
                    {
                      cdoDefRecord(streamID2, varID, levelID);
                      cdoWriteRecord(streamID2, field);
                    }
                }
            }
        }
    }

  cdoStreamClose(streamID2);
  cdoStreamClose(streamID1);

  cdoFinish();

  return nullptr;
}
