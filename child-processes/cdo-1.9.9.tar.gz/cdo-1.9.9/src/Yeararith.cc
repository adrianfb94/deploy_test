/*
  This file is part of CDO. CDO is a collection of Operators to
  manipulate and analyse Climate model Data.

  Copyright (C) 2003-2020 Uwe Schulzweida, <uwe.schulzweida AT mpimet.mpg.de>
  See COPYING file for copying and redistribution conditions.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; version 2 of the License.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
*/

/*
   This module contains the following operators:

      Yeararith  yearadd         Add yearly time series
      Yeararith  yearsub         Subtract yearly time series
      Yeararith  yearmul         Multiply yearly time series
      Yeararith  yeardiv         Divide yearly time series
*/

#include <cdi.h>

#include <climits>

#include "cdo_vlist.h"
#include "cdo_season.h"
#include "functs.h"
#include "process_int.h"


static int
getYear(const int64_t vdate)
{
  int year, mon, day;
  cdiDecodeDate(vdate, &year, &mon, &day);
  return year;
}

static void
addOperators(void)
{
  // clang-format off
  cdoOperatorAdd("yearadd",  func_add, 0, nullptr);
  cdoOperatorAdd("yearsub",  func_sub, 0, nullptr);
  cdoOperatorAdd("yearmul",  func_mul, 0, nullptr);
  cdoOperatorAdd("yeardiv",  func_div, 0, nullptr);
  // clang-format on
}

void *
Yeararith(void *process)
{
  int nrecs;
  int varID, levelID;

  cdoInitialize(process);

  addOperators();

  const auto operatorID = cdoOperatorID();
  const auto operfunc = cdoOperatorF1(operatorID);

  operatorCheckArgc(0);

  const auto streamID1 = cdoOpenRead(0);
  const auto streamID2 = cdoOpenRead(1);

  const auto vlistID1 = cdoStreamInqVlist(streamID1);
  const auto vlistID2 = cdoStreamInqVlist(streamID2);
  const auto vlistID3 = vlistDuplicate(vlistID1);

  vlistCompare(vlistID1, vlistID2, CMP_ALL);

  VarList varList1;
  varListInit(varList1, vlistID1);

  const auto gridsizemax = vlistGridsizeMax(vlistID1);

  Field field;
  field.resize(gridsizemax);

  const auto taxisID1 = vlistInqTaxis(vlistID1);
  const auto taxisID2 = vlistInqTaxis(vlistID2);
  const auto taxisID3 = taxisDuplicate(taxisID1);
  vlistDefTaxis(vlistID3, taxisID3);

  const auto streamID3 = cdoOpenWrite(2);
  cdoDefVlist(streamID3, vlistID3);


  FieldVector2D vars2;
  fieldsFromVlist(vlistID2, vars2, FIELD_VEC);

  int year0 = -INT_MAX + 1;
  int year2last = 0;
  int tsID2 = 0;
  int tsID = 0;
  while ((nrecs = cdoStreamInqTimestep(streamID1, tsID)))
    {
      const auto year = getYear(taxisInqVdate(taxisID1));
      if (year > year0)
        {
          bool lfound = false;
          int nrecs2;
          while ((nrecs2 = cdoStreamInqTimestep(streamID2, tsID2)))
            {
              tsID2++;
              const auto year2 = getYear(taxisInqVdate(taxisID2));
              if (year == year2)
                {
                  lfound = true;
                  year0 = year;
                  for (int recID = 0; recID < nrecs2; recID++)
                    {
                      size_t nmiss;
                      cdoInqRecord(streamID2, &varID, &levelID);
                      cdoReadRecord(streamID2, vars2[varID][levelID].vec_d.data(), &nmiss);
                      vars2[varID][levelID].nmiss = nmiss;
                    }
                  break;
                }

              if (tsID2 > 1 && year2 <= year2last) cdoAbort("stream2 doesn't contain yearly data!");
              year2last = year2;
            }

          if (!lfound) cdoAbort("Data of year %d not found in stream2!", year);
        }
      
      taxisCopyTimestep(taxisID3, taxisID1);
      cdoDefTimestep(streamID3, tsID);

      for (int recID = 0; recID < nrecs; recID++)
        {
          cdoInqRecord(streamID1, &varID, &levelID);
          cdoReadRecord(streamID1, field.vec_d.data(), &field.nmiss);
          field.grid = varList1[varID].gridID;
          field.missval = varList1[varID].missval;

          vfarfun(field, vars2[varID][levelID], operfunc);

          cdoDefRecord(streamID3, varID, levelID);
          cdoWriteRecord(streamID3, field.vec_d.data(), field.nmiss);
        }

      tsID++;
    }

  cdoStreamClose(streamID3);
  cdoStreamClose(streamID2);
  cdoStreamClose(streamID1);

  cdoFinish();

  return nullptr;
}
