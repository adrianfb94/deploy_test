#ifndef CDO_CDI_WRAPPER_H
#define CDO_CDI_WRAPPER_H

// convert a CDI filetype to string
const char *cdi_filetype2str(int filetype);

// convert a CDI datatype to string
const char *cdi_datatype2str(int datatype);
int cdi_str2datatype(const char *datatypestr);

// create Taxis(cdi) with added check/setting of taxisType
int cdoTaxisCreate(int taxisType);

// cdi
extern "C" void cdiDefTableID(int tableID);
extern "C" void gridGenXvals(int xsize, double xfirst, double xlast, double xinc, double *xvals);
extern "C" void gridGenYvals(int gridtype, int ysize, double yfirst, double ylast, double yinc, double *yvals);

#endif
