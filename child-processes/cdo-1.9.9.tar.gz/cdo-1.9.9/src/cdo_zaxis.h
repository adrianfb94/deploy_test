#ifndef CDO_ZAXIS_H
#define CDO_ZAXIS_H

#include <string>

int cdoDefineZaxis(const std::string &zaxisfile);
void defineZaxis(const char *zaxisarg);
int zaxisFromName(const char *zaxisname);
int zaxisFromFile(FILE *zfp, const char *filename);
int zaxis2ltype(int zaxisID);
double cdoZaxisInqLevel(int zaxisID, int levelID);
int cdoZaxisInqLevels(int zaxisID, double *levels);

#endif
