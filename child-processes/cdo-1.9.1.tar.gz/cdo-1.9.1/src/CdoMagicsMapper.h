#ifndef CDO_MAGICS_MAPPER_HH
#define CDO_MAGICS_MAPPER_HH

/* void FindMagicsStruct ( const char *user_name ); */

int GetMagicsParameterInfo( const char *user_name, char *param_value );

#endif
