#ifndef TEMPLATE_PARSER_HH
#define TEMPLATE_PARSER_HH

int init_XMLtemplate_parser( char *Filename );
int updatemagics_and_results_nodes(void);
int quit_XMLtemplate_parser(void);

#endif
