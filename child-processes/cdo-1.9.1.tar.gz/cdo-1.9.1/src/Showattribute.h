void *printAtts(int vlistID, int varOrGlobal, int natts, char *argument); 
