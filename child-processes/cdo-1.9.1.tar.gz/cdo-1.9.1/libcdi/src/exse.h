#ifndef EXSE_H
#define EXSE_H

enum {
  EXSE_SINGLE_PRECISION = 4,
  EXSE_DOUBLE_PRECISION = 8,
};

#endif
